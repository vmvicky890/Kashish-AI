package com.kashish.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.max

private const val VOICE_REQUEST = 410
private const val MIC_PERMISSION = 411

class MemoryDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "kashish_memory.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE qa(id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, answer TEXT NOT NULL)")
        db.execSQL("CREATE TABLE docs(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, source TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun teach(q: String, a: String) {
        writableDatabase.execSQL("INSERT INTO qa(question,answer) VALUES(?,?)", arrayOf(q, a))
    }
    fun addDoc(title: String, body: String) {
        writableDatabase.execSQL("INSERT INTO docs(title,body,source) VALUES(?,?,?)",
            arrayOf(title, body, "Wikipedia"))
    }
    fun answer(q: String): String? {
        val c = readableDatabase.rawQuery("SELECT question,answer FROM qa ORDER BY id DESC", null)
        var best = 0.0
        var result: String? = null
        while (c.moveToNext()) {
            val score = similarity(q, c.getString(0))
            if (score > best) {
                best = score
                result = c.getString(1)
            }
        }
        c.close()
        if (best >= 0.22) return result

        val d = readableDatabase.rawQuery("SELECT title,body FROM docs ORDER BY id DESC", null)
        var docScore = 0.0
        var docAnswer: String? = null
        while (d.moveToNext()) {
            val s = similarity(q, d.getString(0) + " " + d.getString(1).take(1800))
            if (s > docScore) {
                docScore = s
                docAnswer = "${d.getString(0)}\\n${d.getString(1).take(900)}"
            }
        }
        d.close()
        return if (docScore >= 0.08) docAnswer else null
    }
    fun counts(): Pair<Int, Int> {
        fun count(table: String): Int {
            val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null)
            c.moveToFirst()
            val n = c.getInt(0)
            c.close()
            return n
        }
        return Pair(count("qa"), count("docs"))
    }
}

private fun words(s: String): Set<String> =
    s.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        .split(Regex("\\s+")).filter { it.length > 1 }.toSet()

private fun similarity(a: String, b: String): Double {
    val x = words(a)
    val y = words(b)
    if (x.isEmpty() || y.isEmpty()) return 0.0
    val overlap = x.intersect(y).size.toDouble() / max(1, x.union(y).size)
    return overlap
}

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var db: MemoryDb
    private lateinit var chatBox: LinearLayout
    private lateinit var input: EditText
    private lateinit var scroll: ScrollView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val bg = 0xFF0B1020.toInt()
    private val panel = 0xFF151D32.toInt()
    private val purple = 0xFF9B7BFF.toInt()
    private val white = 0xFFF3F4FA.toInt()
    private val muted = 0xFF9AA6C0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = MemoryDb(this)
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("KASHISH", "नमस्ते! मैं KASHISH AI हूँ। मुझे सवाल सिखाओ या Wikipedia से जानकारी लाओ।")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("hi", "IN")
    }

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 20, 18, 14)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 26f)
            setPadding(18, 16, 18, 16)
        }
        header.addView(label("KASHISH AI", 24f, white, true))
        header.addView(label("PERSONAL LEARNING ASSISTANT  •  V1 ANDROID", 10f, purple, true))
        val status = label("Local memory  |  Internet learning  |  Voice", 12f, muted)
        header.addView(status)
        outer.addView(header, LinearLayout.LayoutParams(-1, -2))

        scroll = ScrollView(this).apply { isFillViewport = true }
        chatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(2, 16, 2, 12)
        }
        scroll.addView(chatBox)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, 22f)
            setPadding(10, 10, 10, 10)
        }
        input = EditText(this).apply {
            hint = "KASHISH से कुछ पूछो..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = rounded(0xFF202A43.toInt(), 16f)
            setPadding(14, 12, 14, 12)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        controls.addView(input, LinearLayout.LayoutParams(-1, -2))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        row.addView(actionButton("Send", purple) { sendMessage() }, weightParams())
        row.addView(actionButton("Teach", 0xFF33415F.toInt()) { showTeachDialog() }, weightParams())
        row.addView(actionButton("Learn", 0xFF33415F.toInt()) { learnTopic() }, weightParams())
        row.addView(actionButton("Voice", 0xFF33415F.toInt()) { startVoice() }, weightParams())
        controls.addView(row)
        outer.addView(controls, LinearLayout.LayoutParams(-1, -2))
        setContentView(outer)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 48, 1f).apply {
        setMargins(3, 9, 3, 0)
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 11f
            isAllCaps = false
            setTextColor(white)
            background = rounded(color, 14f)
            setOnClickListener { click() }
        }

    private fun addMessage(who: String, text: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(if (who == "You") 0xFF292343.toInt() else panel, 18f)
            setPadding(14, 10, 14, 10)
        }
        card.addView(label(who, 11f, purple, true))
        card.addView(label(text, 15f, white))
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 9) }
        chatBox.addView(card, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        input.setText("")
        addMessage("You", q)
        val response = db.answer(q) ?: "यह जानकारी अभी मेरी मेमोरी में नहीं है। Teach दबाकर मुझे सिखाओ या Learn से Wikipedia खोजो।"
        addMessage("KASHISH", response)
    }

    private fun showTeachDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 8, 20, 0)
        }
        val q = EditText(this).apply { hint = "कौन-सा सवाल याद रखूँ?" }
        val a = EditText(this).apply { hint = "इसका सही जवाब क्या है?"; minLines = 3 }
        box.addView(q); box.addView(a)
        android.app.AlertDialog.Builder(this)
            .setTitle("KASHISH को सिखाएँ")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                if (q.text.isNotBlank() && a.text.isNotBlank()) {
                    db.teach(q.text.toString(), a.text.toString())
                    addMessage("KASHISH", "सीख लिया! यह जानकारी फोन की local memory में सेव है।")
                }
            }.show()
    }

    private fun learnTopic() {
        val field = EditText(this).apply { hint = "उदाहरण: quantum physics" }
        android.app.AlertDialog.Builder(this)
            .setTitle("Internet learning")
            .setMessage("Wikipedia से एक सारांश खोजेंगे। सेव करने से पहले तुम उसकी समीक्षा करोगे।")
            .setView(field)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Search") { _, _ ->
                val topic = field.text.toString().trim()
                if (topic.isNotEmpty()) fetchWikipedia(topic)
            }.show()
    }

    private fun fetchWikipedia(topic: String) {
        addMessage("KASHISH", "Wikipedia पर खोज रही हूँ: $topic")
        thread {
            try {
                val query = URLEncoder.encode(topic, "UTF-8")
                val searchUrl = URL("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$query&format=json")
                val searchJson = JSONObject(searchUrl.openConnection().apply {
                    connectTimeout = 12000; readTimeout = 12000
                    setRequestProperty("User-Agent", "KASHISH-AI-Android/1.0")
                }.getInputStream().bufferedReader().use { it.readText() })
                val results = searchJson.getJSONObject("query").getJSONArray("search")
                if (results.length() == 0) throw Exception("कोई परिणाम नहीं मिला।")
                val titles = ArrayList<String>()
                for (i in 0 until results.length()) titles.add(results.getJSONObject(i).getString("title"))
                runOnUiThread {
                    android.app.AlertDialog.Builder(this)
                        .setTitle("एक विषय चुनें")
                        .setItems(titles.toTypedArray()) { _, which -> fetchSummary(titles[which]) }
                        .setNegativeButton("Cancel", null).show()
                }
            } catch (e: Exception) {
                runOnUiThread { addMessage("KASHISH", "Internet search में समस्या: ${e.message}") }
            }
        }
    }

    private fun fetchSummary(title: String) {
        thread {
            try {
                val encoded = URLEncoder.encode(title, "UTF-8")
                val url = URL("https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exintro=1&titles=$encoded&format=json")
                val obj = JSONObject(url.openConnection().apply {
                    connectTimeout = 12000; readTimeout = 12000
                    setRequestProperty("User-Agent", "KASHISH-AI-Android/1.0")
                }.getInputStream().bufferedReader().use { it.readText() })
                val pages = obj.getJSONObject("query").getJSONObject("pages")
                val page = pages.getJSONObject(pages.keys().next())
                val body = page.optString("extract", "")
                val actualTitle = page.optString("title", title)
                runOnUiThread {
                    if (body.isBlank()) { addMessage("KASHISH", "इस पेज का सारांश उपलब्ध नहीं है।"); return@runOnUiThread }
                    android.app.AlertDialog.Builder(this)
                        .setTitle(actualTitle)
                        .setMessage(body.take(3500))
                        .setNegativeButton("Don't save", null)
                        .setPositiveButton("Save to memory") { _, _ ->
                            db.addDoc(actualTitle, body)
                            addMessage("KASHISH", "Wikipedia सारांश local memory में सेव कर दिया।")
                        }.show()
                }
            } catch (e: Exception) {
                runOnUiThread { addMessage("KASHISH", "सारांश नहीं ला सकी: ${e.message}") }
            }
        }
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), MIC_PERMISSION)
            return
        }
        launchRecognizer()
    }

    private fun launchRecognizer() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "KASHISH से बोलकर पूछें")
            }
            startActivityForResult(intent, VOICE_REQUEST)
        } catch (_: Exception) {
            addMessage("KASHISH", "इस फोन पर speech recognition उपलब्ध नहीं है।")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIC_PERMISSION && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchRecognizer()
        } else if (requestCode == MIC_PERMISSION) {
            addMessage("KASHISH", "Voice input के लिए microphone permission चाहिए।")
        }
    }

    @Deprecated("Uses Android activity result API for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                addMessage("You (voice)", spoken)
                val response = db.answer(spoken) ?: "यह जानकारी अभी मेरी मेमोरी में नहीं है। Teach या Learn का इस्तेमाल करो।"
                addMessage("KASHISH", response)
                if (ttsReady) tts?.speak(response.take(1200), TextToSpeech.QUEUE_FLUSH, null, "kashish_reply")
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
